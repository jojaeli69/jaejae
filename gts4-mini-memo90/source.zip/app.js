App({onCreate(){console.log('Mini Memo UX 0.9: recorder hook is not connected')},onDestroy(){}});
