/* Legacy 1.0 phone Side Service. This retains the original DarkMemo /memo JSON
 * wire protocol. Requires the user's Android companion server and pairing key.
 * NOT verified in Zepp OS 1.0 on GTS 4 Mini yet.
 */
function packetBytes(packet){const s=JSON.stringify(packet).replace(/[\u007f-\uffff]/g,c=>'\\u'+('0000'+c.charCodeAt(0).toString(16)).slice(-4));const b=new Uint8Array(s.length);for(let i=0;i<s.length;i++)b[i]=s.charCodeAt(i);return b.buffer}
function packetRead(raw){const b=raw instanceof ArrayBuffer?new Uint8Array(raw):new Uint8Array(raw.buffer,raw.byteOffset,raw.byteLength);let t='';for(let i=0;i<b.length;i++)t+=String.fromCharCode(b[i]);return JSON.parse(t)}
function pairingKey(){let s=settings.settingsStorage.getItem('bridge_key')||'';try{s=JSON.parse(s)}catch(_){}return typeof s==='string'?s.trim():''}
AppSideService({
 onInit(){
  this.live=true;this.pending=false;
  this.handler=(raw)=>{
   let p;try{p=packetRead(raw)}catch(e){return}
   if(p.dm!==1||!Number.isInteger(p.id)||this.pending)return;
   this.pending=true;
   let done=false;
   const reply=(data)=>{if(done)return;done=true;clearTimeout(timeout);this.pending=false;if(this.live)messaging.peerSocket.send(packetBytes({dm:1,id:p.id,...data}))};
   const timeout=setTimeout(()=>reply({ok:false,error:'휴대폰 응답 시간 초과'}),8000);
   fetch({url:'http://127.0.0.1:4089/memo',method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...p,key:pairingKey()})})
     .then(r=>{let b=r.body;if(typeof b==='string')b=JSON.parse(b);if(!b||typeof b.ok!=='boolean')throw Error('invalid server response');reply(b)})
     .catch(e=>reply({ok:false,error:'Android 수신 앱 연결 실패: '+String(e&&e.message||e).slice(0,50)}));
  };
  messaging.peerSocket.addListener('message',this.handler);
 },
 onDestroy(){this.live=false;try{messaging.peerSocket.removeListener('message',this.handler)}catch(_){}}
});
