/**
 * GTS4 Mini Memo UI port. Pixel coordinates and original image sprites originate
 * from user's working GTS4 Memo 1.1.3 (390x450 -> 336x384).
 * DANGER: no verified GTS4 Mini mic recorder hook. UI cannot claim audio capture.
 */
import {makeFace,makeFaceData,openFaceSensors} from '../lib/face_engine.js';
import {createMemoController} from '../lib/controller.js';
import {makeBackend} from '../lib/native_backend.js';
import {createMicTrial} from '../lib/mic_trial.js';
import {openLegacyFS,makeDiagnosticWav} from '../lib/legacy_fs.js';
import {createLegacyTransfer} from '../lib/legacy_transfer.js';
import {createZeppTimerScheduler} from '../lib/zepp_timer_scheduler.js';
import {createMemoScreenHold} from '../lib/recording_screen_hold.js';
import {createDiagnosticPayload} from '../lib/diagnostic_qr.js';
const X=n=>Math.round(n*336/390),Y=n=>Math.round(n*384/450);
let cleanup=null;
Page({
 build(){
  const ui=hmUI,widgets=[], sensor=(typeof hmSensor!=='undefined')?hmSensor:null;
  const sensors=sensor?openFaceSensors(sensor):{};
  let face=null,ctr=null,view='',watchTimer=null,lastResult=null;
  let selectedFiles=[],listOffset=0,testFile=null;
  let transfer=null, micTrial=null, lastMicReport=null;
  const timerScheduler=createZeppTimerScheduler(typeof timer!=='undefined'?timer:null);
  const screenHold=createMemoScreenHold(typeof hmSetting!=='undefined'?hmSetting:null,()=>Date.now());
  const storage=typeof hmFS!=='undefined'?openLegacyFS(hmFS):null;
  const ble=typeof hmBle!=='undefined'?hmBle:null;
  if(storage && ble && timerScheduler)transfer=createLegacyTransfer(storage,ble,msg=>showStatus(msg),timerScheduler);
  let vibSensor=null;
  try{if(sensor && sensor.id && sensor.id.VIBRATE!==undefined)vibSensor=sensor.createSensor(sensor.id.VIBRATE)}catch(_){vibSensor=null}

  const add=(type,p)=>{let w=ui.createWidget(type,p);widgets.push(w);return w};
  function clear(){
   if(face){face.destroy();face=null}
   for(let i=widgets.length-1;i>=0;i--){try{ui.deleteWidget(widgets[i])}catch(e){}}
   widgets.length=0;
  }
  function rect(x,y,w,h,color){return add(ui.widget.FILL_RECT,{x:X(x),y:Y(y),w:X(w),h:Y(h),color})}
  function label(x,y,w,h,msg,size=22,color=0xffffff,center=true){return add(ui.widget.TEXT,{x:X(x),y:Y(y),w:X(w),h:Y(h),text:msg,text_size:X(size),color,align_h:center?ui.align.CENTER_H:ui.align.LEFT,align_v:ui.align.CENTER_V})}
  function pill(x,y,w,h,msg,fn,color=0x1c1c1e,ink=0xffffff,rad=22){return add(ui.widget.BUTTON,{x:X(x),y:Y(y),w:X(w),h:Y(h),radius:X(rad),text:msg,text_size:X(22),color:ink,normal_color:color,press_color:0x3a3a3c,click_func:fn})}
  function initView(type,title){clear();view=type;rect(0,0,390,450,0x000000);return title?label(20,21,350,55,title,28):null}
  function mainHome(reason){
   const headerLabel=initView('home','메모');
   let debugTaps=0,debugLast=0;
   if(headerLabel&&headerLabel.addEventListener)headerLabel.addEventListener(ui.event.CLICK_UP,()=>{
    const time=Date.now();debugTaps=time-debugLast<900?debugTaps+1:1;debugLast=time;
    if(debugTaps>=3)showDiagnostics();
   });
   // Compact visible diagnostics entry for first-device preflight; triple-tap title still works.
   pill(303,30,65,39,'진단',()=>showDiagnostics(),0x18181a,0xaaaab3,14);
   for(const [x,y,w,h,c,r] of [[123,144,144,144,0x121214,72],[125,146,140,140,0x343437,70],[127,148,136,136,0x171719,68]]){
     add(ui.widget.FILL_RECT,{x:X(x),y:Y(y),w:X(w),h:Y(h),radius:X(r),color:c});
   }
   const hit=add(ui.widget.FILL_RECT,{x:X(131),y:Y(152),w:X(128),h:Y(128),radius:X(64),color:0x222222});
   const hint=label(131,195,128,48,'1.5초 꾹',21,0xe5e5e5);
   if(hint.setEnable)hint.setEnable(false);
   if(hit.addEventListener){
     hit.addEventListener(ui.event.CLICK_DOWN,()=>ctr.press('screen'));
     hit.addEventListener(ui.event.CLICK_UP,()=>ctr.release('screen'));
     if(ui.event.MOVE_OUT!==undefined)hit.addEventListener(ui.event.MOVE_OUT,()=>ctr.cancelHold());
   }
   pill(24,359,342,62,'목록  ·  '+ctr.files().length+'개  ›',()=>ctr.list(),0x1c1c1e,0xc7c7cc,22);
   if(reason)label(18,295,354,44,reason,17,0xff9999)
  }
  function header(title,back){
   if(back)pill(20,20,48,48,'‹',back);
   label(back?85:28,23,back?277:334,46,title,28,0xffffff,false);
  }
  function fileName(file){
   const m=/memo-(\d+)\.(opus|wav)$/.exec(file||'');
   if(!m)return '메모';
   const d=new Date(Number(m[1]));
   if(isNaN(d.getTime()))return '메모';
   const two=x=>String(x).padStart(2,'0');
   return (d.getMonth()+1)+'월 '+d.getDate()+'일  '+two(d.getHours())+':'+two(d.getMinutes());
  }
  function showList(index=0){
   listOffset=Math.max(0,Math.floor(index/3)*3);
   initView('list');header('모든 메모',()=>ctr.home());
   const files=ctr.files(),total=Math.max(1,Math.ceil(files.length/3));
   if(!files.length){
    label(28,154,334,60,'아직 메모가 없어요',26);
    label(28,222,334,50,'처음 화면에서 메모를 시작하세요.',19,0x989a9d);return;
   }
   pill(250,52,116,34,'선택',()=>{selectedFiles=[];showSelect(listOffset)},0x242424,0xe5e5e5);
   for(let row=0;row<3;row++){
    const i=listOffset+row,file=files[i];if(!file)break;
    const y=92+row*84;
    pill(24,y,342,76,'',()=>showDetail(i),0x1c1c1e);
    const title=label(42,y+9,300,30,fileName(file),22,0xffffff,false);
    const info=label(42,y+41,300,25,'워치 메모',16,0x989a9d,false);
    if(title.addEventListener)title.addEventListener(ui.event.CLICK_UP,()=>showDetail(i));
    if(info.addEventListener)info.addEventListener(ui.event.CLICK_UP,()=>showDetail(i));
   }
   if(listOffset>0)pill(24,366,99,54,'‹ 이전',()=>showList(listOffset-3));
   label(130,372,130,40,String(Math.floor(listOffset/3)+1)+' / '+String(total),20,0x989a9d);
   if(listOffset+3<files.length)pill(267,366,99,54,'다음 ›',()=>showList(listOffset+3));
  }
  function showSelect(index=0){
   const files=ctr.files();listOffset=Math.max(0,Math.floor(index/3)*3);
   selectedFiles=selectedFiles.filter(f=>files.includes(f));
   initView('select');header('메모 선택',()=>showList(listOffset));
   pill(24,57,148,34,selectedFiles.length===files.length?'전체 해제':'전체 선택',()=>{
    selectedFiles=selectedFiles.length===files.length?[]:files.slice();showSelect(listOffset);
   },0x242424,0xe5e5e5);
   label(180,57,186,34,selectedFiles.length+'개 선택',18,0x989a9d);
   for(let row=0;row<3;row++){
    const file=files[listOffset+row];if(!file)break;
    const checked=selectedFiles.includes(file);
    pill(24,101+row*70,342,62,(checked?'●  ':'○  ')+fileName(file),()=>{
     selectedFiles=checked?selectedFiles.filter(f=>f!==file):selectedFiles.concat(file);showSelect(listOffset);
    },checked?0x343437:0x1c1c1e,0xe5e5e5);
   }
   const total=Math.max(1,Math.ceil(files.length/3));
   if(listOffset>0)pill(24,319,100,42,'‹ 이전',()=>showSelect(listOffset-3));
   label(130,320,130,40,(Math.floor(listOffset/3)+1)+' / '+total,18,0x989a9d);
   if(listOffset+3<files.length)pill(266,319,100,42,'다음 ›',()=>showSelect(listOffset+3));
   pill(24,377,342,52,'선택한 '+selectedFiles.length+'개 삭제',()=>{
    if(selectedFiles.length)confirmDelete(selectedFiles.slice());
   },0x331c1c,0xffaaaa);
  }
  function showDetail(index){
   const file=ctr.files()[index];if(!file){showList(0);return}
   initView('detail');header('메모',()=>showList(index));
   label(26,89,338,38,fileName(file),26);
   label(26,132,338,30,'워치 메모',19,0x989a9d);
   pill(137,183,116,116,'재생',()=>showStatus('오디오 재생 미연결'),0x242424,0xffffff,58);
   pill(26,327,338,58,'휴대폰으로 다운로드',()=>{
     if(!storage||!transfer){showStatus('Zepp1 BLE·파일 API 연결 없음');return}
     const bytes=storage.exists(file);
     if(!Number.isFinite(bytes)||bytes<44){showStatus('메모 원본 파일 확인 실패');return}
     try{transfer.startFile(file,bytes,(offset,length)=>storage.readSlice(file,offset,length),result=>showStatus(result.ok?'휴대폰 저장 완료':'전송 실패: '+result.error))}
     catch(e){showStatus('전송 시작 실패: '+String(e).slice(0,50))}
   },0x121c23,0x99aaaa);
   pill(26,397,338,38,'메모 삭제',()=>confirmDelete([file],index),0x000000,0xffaaaa);
  }
  function confirmDelete(selected,index=listOffset){
   initView('confirm');header('선택 삭제',()=>showSelect(index));
   label(28,112,334,50,selected.length+'개를 삭제할까요?',26);
   label(28,180,334,80,'워치 원본이 삭제됩니다.\n휴대폰에 저장한 파일은 유지됩니다.',20,0x989a9d);
   pill(26,297,338,58,'삭제하기',()=>{
    const count=ctr.deleteSelected(selected);
    if(count!==selected.length)showStatus('파일 삭제 미연결 · 원본 보존');
    else showList(0);
   },0x331c1c,0xffaaaa);
   pill(26,370,338,58,'취소',()=>selectedFiles.length?showSelect(index):showDetail(index));
  }
  function showStatus(reason){initView('status','메모');label(23,122,344,133,String(reason||'상태 확인').slice(0,100),20,0xd8d8d8);pill(26,351,338,58,'돌아가기',()=>ctr.home())}
  function showDiagnosticQr(r){
    const value=createDiagnosticPayload(r);
    initView('diagnostic-qr');
    header('진단 결과 QR',()=>showDiagnostics());
    label(20,77,350,49,'코드: '+String(r&&r.code||'NOT_TESTED').slice(0,30),16,0xd1d1d8);
    if(ui.widget.QRCODE!==undefined){
      try{add(ui.widget.QRCODE,{content:value,x:X(71),y:Y(136),w:X(248),h:Y(248)});}
      catch(e){label(20,145,350,110,'QR 지원 실패\n'+String(r&&r.code||'NOT_TESTED'),18,0xffaaaa);}
    }else label(20,145,350,110,'이 펌웨어에서는 QR 표시 불가',20,0xffaaaa);
    label(20,379,350,28,'원본 음성 미확인 · 개인키 미포함',15,0x989a9d);
    pill(24,408,342,36,'돌아가기',()=>showDiagnostics(),0x242424,0xffffff);
  }
  function showMicTrialResult(r){
    if(!r || r.code==='TRIAL_RUNNING')return;
    lastMicReport=r;
    // Never claim recording success: these are unverified sensor bytes.
    if(r.file)testFile=r.file;
    const summary={code:r.code,events:r.events||0,bytes:r.bytes||0,
      invalid:r.invalidEvents||0,pollFail:r.pollFailures||0,overflows:r.overflowEvents||0,
      rms:r.stats&&r.stats.rms,verified:false};
    try{console.log('[Mini DarkMemo diagnostic] '+JSON.stringify(summary))}catch(_){}
    const head=(r.code==='WAV_PCM16_8K_UNVERIFIED')?'PCM 후보 저장 · 음성 미확인':'마이크 진단: '+r.code;
    const metrics='이벤트 '+summary.events+'회 / '+summary.bytes+'B'+(summary.rms!==undefined?' / RMS '+summary.rms:'');
    showDiagnosticQr(r);
  }
  function showDiagnostics(){
   initView('diagnostics');header('Mini 마이크 진단',()=>ctr.home());
   label(18,76,354,72,'Recorder 시작 차단: 실기기 멈춤 확인\n오디오 수신 경로는 아직 미구현',17,0xffbbbb);
   pill(24,154,342,47,'위험한 마이크 시작 차단 확인',()=>{
     if(!micTrial){showStatus('마이크 테스트 도구 미연결');return}
     const r=micTrial.start();
     if(!r.ok){showStatus(r.code==='UNSAFE_NATIVE_START_WATCH_HANG'?'마이크 안전 차단\n실기기 START 멈춤 확인':'마이크 접근 실패: '+r.code);return}
     initView('mic-trial','마이크 진단 실행 중');
     label(18,110,354,93,'최대 3초간 데이터 수집\n언제든 중지할 수 있어요',20,0xffffff);
     pill(24,267,342,59,'즉시 중지',()=>micTrial.stop(),0x4d2020,0xffffff);
   },0x343437,0xffffff);
   pill(24,211,342,47,'합성 WAV 파일 저장 테스트',()=>{
    if(!storage){showStatus('Zepp OS 파일 API 없음');return}
    try{const wav=makeDiagnosticWav(),name='test-'+Date.now()+'.wav';
      const saved=storage.write(name,wav);const data=storage.readSlice(name,0,44);
      if(data.length!==44||saved.bytes!==wav.length)throw Error('파일 길이 불일치');
      testFile=name;showStatus('합성 테스트 저장 확인\n'+name+' · '+saved.bytes+'B');
    }catch(e){showStatus('파일 테스트 실패: '+String(e).slice(0,65))}
   },0x24242c,0xffffff);
   pill(24,268,342,47,'진단 테스트파일 S25 전송',()=>{
     if(!testFile||!storage||!transfer){showStatus('테스트 파일·수신연결 미준비');return}
     try{transfer.startFile(testFile,storage.exists(testFile),(offset,length)=>storage.readSlice(testFile,offset,length),r=>showStatus(r.ok?'S25 테스트 파일 저장 확인':'S25 전송 실패: '+r.error))}
     catch(e){showStatus('전송 오류: '+String(e).slice(0,50))}
   });
   pill(24,325,165,43,'워치페이스',()=>showFacePreview());
   pill(200,325,166,43,'돌아가기',()=>ctr.home());
   pill(24,376,342,42,'최근 진단 결과 QR',()=>showDiagnosticQr(lastMicReport));
  }
  function showFacePreview(){
   clear();view='face-preview';face=makeFace(ui);face.update(makeFaceData(sensors));
   const mask=add(ui.widget.IMG,{src:'transparent_touch.png',x:0,y:0,w:336,h:384});
   if(mask.setEnable)mask.setEnable(true);
   if(mask.addEventListener)mask.addEventListener(ui.event.CLICK_UP,()=>ctr.home());
  }
  function showClock(){
   clear();view='clock';face=makeFace(ui);face.update(makeFaceData(sensors));
   // A transparent image receives touch events while preserving the complete watchface.
   const mask=add(ui.widget.IMG,{src:'transparent_touch.png',x:0,y:0,w:336,h:384});
   if(mask.setEnable)mask.setEnable(true);
   if(mask.addEventListener){
    mask.addEventListener(ui.event.CLICK_DOWN,()=>ctr.press('screen'));
    mask.addEventListener(ui.event.CLICK_UP,()=>ctr.release('screen'));
   }
  }
  function showDark(){
   initView('dark');
   const mask=add(ui.widget.IMG,{src:'transparent_touch.png',x:0,y:0,w:336,h:384});
   if(mask.setEnable)mask.setEnable(true);
   if(mask.addEventListener){
    mask.addEventListener(ui.event.CLICK_DOWN,()=>ctr.press('screen'));
    mask.addEventListener(ui.event.CLICK_UP,()=>ctr.release('screen'));
   }
  }
  function render(v){
   if(v.view===view){
    if(v.view==='clock'&&face)face.update(makeFaceData(sensors));
    return;
   }
   switch(v.view){
    case 'home': mainHome(v.reason);break;
    case 'list':showList(listOffset);break;
    case 'clock':showClock();break;
    case 'dark':showDark();break;
    case 'status':showStatus(v.reason);break;
    default:showStatus(v.reason||'녹음 상태 확인 중');break;
   }
  }
  function vibrate(){try{if(vibSensor){vibSensor.stop();vibSensor.scene=23;vibSensor.start()}}catch(_){}}
  const native=makeBackend();
  const backend={...native,deleteFile(name){return native.deleteFile(name)||(storage?storage.remove(name):false)}};
  micTrial=createMicTrial({hmSensor:sensor,timer:(typeof timer!=='undefined'?timer:null),now:()=>Date.now()},storage,showMicTrialResult);
  const scheduleHold=(fn,ms)=>{
    if(typeof timer==='undefined'||typeof timer.createTimer!=='function')return null;
    const id=timer.createTimer(ms,0,()=>{
      try{timer.stopTimer(id)}catch(_){}
      fn();
    },{});
    if(!Number.isInteger(id)||id<0)throw Error('hold timer failed');
    return id;
  };
  ctr=createMemoController({
   now:()=>Date.now(),backend,vibrate,scheduleHold,
   onRecordingStart:()=>{const r=screenHold.start();if(!r.ok)console.log('[DarkMemo screen] '+r.code)},
   onRecordingEnd:()=>{const r=screenHold.stop();if(!r.ok)console.log('[DarkMemo screen] '+r.code)},
   cancelHold:id=>{if(typeof timer!=='undefined'&&timer.stopTimer)timer.stopTimer(id)},
   render(v){lastResult=v;render(v)}
  });
  if(storage)ctr.restoreFiles(storage.list());else ctr.home();
  function redrawNow(){
   screenHold.tick(); // release bright-screen override at 90 min, even if memo is still active
   ctr.step();
   if((view==='clock'||view==='face-preview')&&face)face.update(makeFaceData(sensors));
  }
  if(typeof timer!=='undefined'&&typeof timer.createTimer==='function'){
   watchTimer=timer.createTimer(1000,1000,redrawNow,{});
  }
  if(typeof hmApp!=='undefined'&&typeof hmApp.registerKeyEvent==='function'){
   hmApp.registerKeyEvent((key,action)=>{
    const k=hmApp.key||{},a=hmApp.action||{};
    if(key!==k.HOME&&key!==k.SELECT&&key!==k.UP)return false;
    if(action===a.PRESS){return ctr.press('key')}
    if(action===a.RELEASE){const held=ctr.peek().held;ctr.release('key');return held}
    if(action===a.LONG_PRESS){return ctr.keyLong()}
    return false;
   });
  }
  try{if(ui.setStatusBarVisible)ui.setStatusBarVisible(false)}catch(_){}
  cleanup=()=>{
   if(ctr)ctr.destroy();
   screenHold.stop('APP_DESTROY'); // idempotent; restore user screen behavior
   try{if(typeof hmApp!=='undefined'&&typeof hmApp.unregisterKeyEvent==='function')hmApp.unregisterKeyEvent()}catch(_){}
   if(micTrial)micTrial.dispose();
   if(watchTimer!==null&&typeof timer!=='undefined'&&timer.stopTimer)timer.stopTimer(watchTimer);
   // Do not call fake stop; if a native hook is live, cleanup is a device-specific task.
   if(transfer)transfer.dispose();
   if(timerScheduler)timerScheduler.dispose();
   try{if(vibSensor)vibSensor.stop()}catch(_){}
   clear();
  };
 },
 onDestroy(){if(cleanup){cleanup();cleanup=null}}
});
