AppSettingsPage({build(props){return View({style:{padding:'18px'}},[
 Text({style:{fontSize:'23px'}},'GTS 4 Mini 메모'),
 Text({},'갤럭시 S25의 기존 다크메모 수신 앱에서 발급한 연결 코드를 입력하세요.'),
 TextInput({label:'연결 코드',settingsKey:'bridge_key',placeholder:'코드 붙여넣기'}),
 Text({},'워치에서 다운로드를 선택하면 기존 수신 앱으로 WAV 전송을 시도합니다.')
])}});
